﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    // Diccionario: nombre del estudiante -> Array con sus calificaciones.
    // Al ignorar mayúsculas, "ana" y "Ana" cuentan como el mismo estudiante.
    static Dictionary<string, double[]> estudiantes = new(StringComparer.OrdinalIgnoreCase);

    static void Main()
    {
        bool salir = false;

        // Ciclo while: el menú se repite hasta elegir "Salir".
        while (!salir)
        {
            Console.WriteLine("\n1. Ingresar Calificaciones\n2. Ver Promedio de Calificaciones\n3. Salir");
            Console.Write("Elige una opción: ");

            // switch para manejar las opciones del menú.
            switch (Console.ReadLine())
            {
                case "1": Ingresar(); break;
                case "2": VerPromedio(); break;
                case "3": salir = true; break;
                default: Console.WriteLine("Opción no válida."); break; // no cierra el programa
            }
        }
    }

    static void Ingresar()
    {
        Console.Write("Nombre del estudiante: ");
        string nombre = Console.ReadLine()?.Trim() ?? "";
        if (nombre == "") { Console.WriteLine("El nombre no puede estar vacío."); return; }

        // TryParse convierte el texto a número sin lanzar excepciones; si falla, se repite la pregunta.
        int cantidad;
        Console.Write("¿Cuántas calificaciones? ");
        while (!int.TryParse(Console.ReadLine(), out cantidad) || cantidad <= 0)
            Console.Write("Entrada inválida. Ingresa un entero mayor que 0: ");

        double[] notas = new double[cantidad];

        // Ciclo for: pide las calificaciones una por una y las guarda en el Array.
        for (int i = 0; i < cantidad; i++)
        {
            Console.Write($"Calificación {i + 1}: ");
            while (!double.TryParse(Console.ReadLine(), out notas[i]) || notas[i] < 0 || notas[i] > 100)
                Console.Write("Entrada inválida. Ingresa un número entre 0 y 100: ");
        }

        estudiantes[nombre] = notas; // registra o actualiza al estudiante
        Console.WriteLine($"Calificaciones de {nombre} guardadas.");
    }

    static void VerPromedio()
    {
        Console.Write("Nombre del estudiante a consultar: ");
        string buscado = Console.ReadLine()?.Trim().ToLower() ?? "";

        // Búsqueda con métodos de string: primero coincidencia exacta, luego parcial (Contains).
        string? nombre = estudiantes.Keys.FirstOrDefault(n => n.ToLower() == buscado)
                      ?? estudiantes.Keys.FirstOrDefault(n => buscado != "" && n.ToLower().Contains(buscado));

        if (nombre == null) { Console.WriteLine("Estudiante no encontrado."); return; }

        // Recorremos el Array sumando las calificaciones para calcular el promedio.
        double suma = 0;
        foreach (double nota in estudiantes[nombre]) suma += nota;

        Console.WriteLine($"\nEstudiante: {nombre}\nPromedio: {suma / estudiantes[nombre].Length:F2}");
    }
}